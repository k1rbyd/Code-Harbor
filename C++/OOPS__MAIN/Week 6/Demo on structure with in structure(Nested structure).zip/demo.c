#include <stdio.h>  
#include <string.h>

struct EMP{
    int emp_id;
    char emp_name[15];
    float emp_sal;
    struct DOB{
        int day;
        int month;
        int year;
    }db;
}e1,e2;

ing main()
{
    e1.emp_id=10;
    strcpy(e1.emp_name,"AAAAAAAAA");
    e1.emp_sal=12000.0;
    e1.db.day=2;
    e1.db.month=12;
    e1.db.year=2004;
    
    printf("%d \t %s \t %f \n",e1.emp_id,e1.emp_name,e1.emp_sal);
    printf("%d \t %d \t %s \n",e1.db.day,e1.db.month,e1.db.year);
    
    scanf("%d %s %f",&e2.emp_id,&e2.emp_name,&e2.emp_sal);
    scanf("%d %d %d",&e2.db.day,&e2.db.month,&e2.db.year);
    
    printf("%d \t %s \t %f \n",e2.emp_id,e2.emp_name,e2.emp_sal);
    printf("%d \t %d \t %s \n",e2.db.day,e2.db.month,e2.db.year);
    
    // extras
    
    struct EMP e3={1,"blahh",123456789};
    struct EMP *e4=&e3;
    printf("%d \t %s \t %d \n",e4->emp_id,e4->emp_name,e4->emp_sal);
    printf("%d \t %s \t %d \n",(*e4).emp_id,(*e4).emp_name,(*e4).emp_sal)
    
}	 	  	 	  	  	     		     	      	       	 	