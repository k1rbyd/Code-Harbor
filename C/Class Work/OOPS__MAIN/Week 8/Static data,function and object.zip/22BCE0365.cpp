#include <iostream>
using namespace std;

class Test
{
    int a;
    static int b;
    public:
        Test()
        {
            a=1;
        }
        void put_data()
        {
            cout<<a<<endl<<b<<endl;
        }
        static void add();
};

int Test::b=10;
void Test::add()
{
    ++b;
}
int main()
{
    Test t1;
    Test::add();
    t1.put_data();
    Test t2;
    t2.put_data();
}