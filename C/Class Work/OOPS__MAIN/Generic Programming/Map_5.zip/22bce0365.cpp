#include <iostream>
#include <map>
using namespace std;

int main()
{
    map<string,char> l;
    l["aaa"]='A';
    l["bbb"]='B';
    l["ccc"]='C';
    map<string,char>::iterator i;
    if(l.find("aaa")==l.end())
    {
        cout<<"NOT FOUND";
    }
    else
    {
        cout<<"FOUND";
    }
    
}