#include <stdio.h>
int main()
{
    int money,price,wrappers,chocos,freef,total;
    printf("Enter the amount:");
    scanf("%d",&money);
    printf("Enter the price:");
    scanf("%d",&price);
    printf("Enter the count of wrappers:");
    scanf("%d",&wrappers);
    chocos = (price/money);
    freef = (chocos/wrappers);
    total = chocos+freef;
    printf("No. of chocolates he bought : %d",total);
}