#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> list1;
    list1.push_back(1);
    list1.push_back(100);
    vector<int> list2;
    list2=list1;
    for(int i=0;i<list2.size();i++)
    {
        cout<<list2[i]<<endl;
    }
}