#include <iostream>
using namespace std;

class A
{
    int a;
    public:
        A()
        {
            a=1;
        }
        void print_data()
        {
            return a;
        }
};

class B
{
    int b;
    public:
        B()
        {
            b=2;
        }
        void print_data()
        {
            return b;
        }
};

void display(A a, B b)
{
    cout<<a.print_data()+b.print_data()<<endl;
}

int main()
{
    A a1;
    B b1;
    display(a1,b1);
}