/*
// this code will most probably not run here, but it logically runs on every other complier.

#include <stdio.h>
int add(int);
int main()
{
    float f;
    int i,j;
    int r1,r2;
    scanf("%f",f);
    i = (int)f+0;           // this will be just the integer value alone
    i = i-1;                // this is becauze it will round the value to the next point
    r1 = add(i);
    j = f-i;                //  here , we will have just the decimal points
    j = j*100000;           // taking the decimal points to the opposite side, with extra zeroes
    r2=add(j);
}

int add(int x)
{
    int y;
    int sum;
    int z;
    if (x<10)
    {
        return x;
    }
    else
    {
        y=x%10;
        z = (x-y)/10;
        sum = y+z;
        x = sum;
        add(x);
    }
}	 	  	 	  	  	     		     	      	       	 	

*/

#include <stdio.h>
#include <stdlib.h>
float sum (int array[],int n)
{
    float f; float z=n;
    if (n==0) 
        return (array[n]);
    f=(array[n]+sum(array,n-1));
    return f;
}
int main()
{
    int *array,n,i;
    float result;
    scanf("%d",&n);
    array=(int *) malloc(n*sizeof(int));
    for (i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    result = sum(array,n);
    printf("%f",result);
}
	 	  	 	  	  	     		     	      	       	 	
