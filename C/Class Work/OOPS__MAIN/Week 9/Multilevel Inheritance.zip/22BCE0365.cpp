#include <iostream>
using namespace std;

class A
{
    private:
        int a1;
    protected:
        int a2;
    public: 
        int a3;
        A()
        {
            cout<<"Im from class A"<<endl;
            a1=10;
            a2=20;
            a3=30;
        }
        ~A()
        {
            cout<<"Destructor of class A"<<endl;
        }
        void print()
        {
            cout<<"Class A"<<endl;
        }
};

class B:public A
{
    private:
        int b1;
    protected:
        int b2;
    public:
        int b3;
        B()
        {	 	  	 	  	  	     		     	      	       	 	
            cout<<"Im from class B"<<endl;
            b1=100;
            b2=200;
            b3=300;
        }
        ~B()
        {
            cout<<"Destructor of class B"<<endl;
        }
        void display()
        {
            cout<<"Class B"<<endl;
        }
};

class C:public B
{
    private:
        int c1;
    protected:
        int c2;
    public:
        int c3;
        C()
        {
            cout<<"Im from class C"<<endl;
            c1=1000;
            c2=2000;
            c3=3000;
        }
        ~C()
        {
            cout<<"Destructor of class C"<<endl;
        }
        void print()
        {	 	  	 	  	  	     		     	      	       	 	
            cout<<"Class C"<<endl;
        }
};

int main()
{
    A a1;
    cout<<"-x-x-x-x-x-x-x-x-x-x-x-x-"<<endl;
    B b1;
    cout<<"-x-x-x-x-x-x-x-x-x-x-x-x-"<<endl;
    C c1;
    cout<<"-x-x-x-x-x-x-x-x-x-x-x-x-"<<endl;
    
    c1.print();
    cout<<endl;
    b1.print();
    cout<<endl;
    a1.print();
    cout<<endl;
}