#include <iostream>
#include <map>
using namespace std;

int main()
{
    map<string,char> l;
    l["aaa"]='A';
    if(l.empty())
    cout<<"EMPTY";
    else
    cout<<"NOT EMPTY";
}