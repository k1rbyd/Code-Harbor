#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> test = {1, 8, 4};
    
    sort(test.begin(), test.end());
    
    for (const auto& num : test) {
        cout << num << " ";
    }
    
    return 0;
}
