#include <iostream>
#include <list>
using namespace std;

int main()
{
    list<int> list1;
    list1.push_front(1);
    list1.push_front(2);
    list1.push_back(4);
    list1.push_back(3);
    
    list<int>::iterator i;
    
    list1.pop_front();
    list1.pop_back();
    
    for(i=list1.begin();i!=list1.end();i++)
    {
        cout<<*i<<endl;
    }
}