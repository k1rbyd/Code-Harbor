#include <stdio.h>
int main()
{
    int a,b,c,d,e;
    float f;
    printf("Enter the values of a and b:");
    scanf("%d%d",&a,&b);
    c=a+b;
    d=a-b;
    e=a*b;
    f=(float)a/b;
    printf("The value of c : %d .\n",c);
    printf("The value of d : %d .\n",d);
    printf("The value of e : %d .\n",e);
    printf("The value of f : %.2f .\n",f);
    return 0;

}