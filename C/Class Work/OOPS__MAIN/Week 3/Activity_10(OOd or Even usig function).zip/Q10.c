#include <stdio.h>
void check(int num);
int main()
{
    int test[1000];
    int i;
    for (i = 0; i < 4; i++)
    {
        scanf("%d", &test[i]);
    }
    for (i = 0; i < 4; i++)
    {
        check(test[i]);
    }
    return 0;
}
void check(int num)
{
    static int even[1000];
    static int odd[1000];
    static int even_size = 0;
    static int odd_size = 0;
    if (num % 2 == 0)
    {
        even[even_size] = num;
        even_size++;
    }
    else
    {
        odd[odd_size] = num;
        odd_size++;
    }
    int i;
    printf("The even numbers are,\n");
    for (i = 0; i < even_size; i++)
    {
        printf("%d\n", even[i]);
    }	 	  	 	  	  	     		     	      	       	 	
    printf("The odd numbers are,\n");
    for (i = 0; i < odd_size; i++)
    {
        printf("%d\n", odd[i]);
    }
}
