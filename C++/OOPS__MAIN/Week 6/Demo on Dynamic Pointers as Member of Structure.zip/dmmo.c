#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct EMP_INFO{
    int *emp_id;
    char *emp_name;
}EMP;

int main()
{
    EMP e;
    e.emp_id=malloc(sizeof(int));
    e.emp_name=malloc(sizeof(char)*10);
    e.emp_id=1;
    strcpy(e.emp_name,"ABC");
    printf("%d \t %s\n",e.emp_id,e.emp_name);
}