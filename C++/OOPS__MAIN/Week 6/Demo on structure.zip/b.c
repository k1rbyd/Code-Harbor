#include <stdio.h>
#include <string.h>
struct EMP{
    int emp_id;
    char emp_name[15];
    float emp_sal;
}e1,e2;
int main()
{
    e1.emp_id=10;
    strcpy(e1.emp_name,"John");
    e1.emp_sal=10000000.0;
    e2.emp_id=20;
    strcpy(e2.emp_name,"Mehhh");    
    e2.emp_sal=20000000.0;
    
    // we can input the data with thisss....
    
    struct EMP e[2];
    int i;
    for(i=0;i<2;i++)
    {
        printf("Enter the emp id:");
        scanf("%d",&e[i].emp_id);
        printf("Enter the emp name:");
        scanf("%s",&e[i].emp_name);
        printf("Enter the emp salary:");
        scanf("%f",&e[i].emp_sal);
    }
    
    printf("The results:\n");
    for(i=0;i<2;i++)
    {
        printf("%d \t %s \t %f\n",e[i].emp_id,e[i].emp_name,e[i].emp_sal);
    }
}	 	  	 	  	  	     		     	      	       	 	
