#include <iostream>
#include <map>
using namespace std;

int main()
{
    map<string, char> grade_list;
    grade_list["aaa"]='A';
    grade_list["bbb"]='B';
    grade_list["ccc"]='C';
    map<string,char>::iterator i;
    for(i=grade_list.begin();i!=grade_list.end();i++)
    {
        cout<<(*i).first<<" "<<(*i).second<<endl;
    }
}