#include <iostream>
using namespace std;

class Base
{
    public:
        virtual void say_hi()
        {
            cout<<"Base Says Hi"<<endl;
        }
        ~Base()
        {
            cout<<"Base Destructor"<<endl;
        }
};

class Derived : public Base
{
    public:
        virtual void say_hi()
        {
            cout<<"Derived Says Hi"<<endl;
        }
        ~Derived()
        {
            cout<<"Derived Destructor"<<endl;   
        }
};

class Derived1 : public Base
{
    public:
        // void say_hi()
        // {
        //     cout<<"Derived1 Says Hi"<<endl;
        // }
        ~Derived1()
        {	 	  	 	  	  	     		     	      	       	 	
            cout<<"Derived1 Destructor"<<endl;
        }
};

int main()
{
    Base b;
    b.say_hi();
    cout<<"---------------------------------"<<endl;
    Derived d;
    d.say_hi();
    cout<<"---------------------------------"<<endl;
    Derived1 d1;
    d1.say_hi();
    cout<<"---------------------------------"<<endl;
}