#include <stdio.h>
#include <string.h>

typedef struct{
    int *emp_id;
    char *emp_name;
    int *emp_basic_pay;
}EMP;

int main()
{
    EMP e1 = {1,"aaaaaaa",123};
    EMP *e2 = &e1;
    scanf("%d %s %d",&e1.emp_id,&e1.emp_name,&e1.emp_basic_pay);
    printf("%d \t %s \t %d \n",e2->emp_id,e2->emp_name,e2->emp_basic_pay);
    printf("%d \t %s \t %d \n",(*e2).emp_id,(*e2).emp_name,(*e2).emp_basic_pay);
}