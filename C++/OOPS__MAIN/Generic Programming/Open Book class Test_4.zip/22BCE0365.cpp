#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

struct Product {
    std::string productName;
    std::string productCategory;
    int productStock;

    Product(const std::string& name, const std::string& category, int stock)
        : productName(name), productCategory(category), productStock(stock) {}
};

class Inventory {
private:
    std::vector<Product> productList;

public:
    void addProduct(const std::string& name, const std::string& category, int stock) {
        productList.emplace_back(name, category, stock);
    }

    void updateProductStock(const std::string& name, int newStock) {
        auto it = std::find_if(productList.begin(), productList.end(), [&](const Product& p) {
            return p.productName == name;
        });

        if (it != productList.end()) {
            it->productStock = newStock;
        } else {
            std::cout << "Product not found!\n";
        }
    }

    void searchProductByName(const std::string& name) {
        auto it = std::find_if(productList.begin(), productList.end(), [&](const Product& p) {	 	  	 	  	  	     		     	      	       	 	
            return p.productName == name;
        });

        if (it != productList.end()) {
            displayProduct(*it);
        } else {
            std::cout << "Product not found!\n";
        }
    }

    void searchProductByCategory(const std::string& category) {
        std::vector<Product> categoryProducts;
        std::copy_if(productList.begin(), productList.end(), std::back_inserter(categoryProducts), [&](const Product& p) {
            return p.productCategory == category;
        });

        if (!categoryProducts.empty()) {
            for (const auto& product : categoryProducts) {
                displayProduct(product);
            }
        } else {
            std::cout << "No products found in the category!\n";
        }
    }

    void displayStock() {
        for (const auto& product : productList) {
            displayProduct(product);
        }
    }

private:
    void displayProduct(const Product& product) {
        std::cout << "Product Name: " << product.productName << ", Category: " << product.productCategory
                  << ", Stock: " << product.productStock << "\n";
    }	 	  	 	  	  	     		     	      	       	 	
};

int main() {
    Inventory productInventory;

    productInventory.addProduct("Phone", "Electronics", 10);
    productInventory.addProduct("Shirt", "Clothing", 20);
    productInventory.addProduct("Book", "Books", 15);

    productInventory.updateProductStock("Phone", 5);

    productInventory.searchProductByName("Shirt");

    productInventory.searchProductByCategory("Books");

    productInventory.displayStock();

    return 0;
}
