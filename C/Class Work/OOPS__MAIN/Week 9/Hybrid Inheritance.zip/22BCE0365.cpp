#include <iostream>
using namespace std;

class Base
{
    public:
        Base()
        {
            cout<<"This is from Base"<<endl;
        }
};

class Derived : public Base
{
    public:
        Derived()
        {
            cout<<"This is from Derived"<<endl;
        }
};

class Derived1 : public Base
{
    public:
        Derived1()
        {
            cout<<"This is from Derived"<<endl;
        }
};

class Base2 : public Derived, public Derived1
{
    public:
        Base2()
        {
            cout<<"This is from Base2"<<endl;
        }	 	  	 	  	  	     		     	      	       	 	
};

int main()
{
    Base b;
    cout<<"----------------------------------------"<<endl;
    Derived d1;
    cout<<"----------------------------------------"<<endl;
    Derived1 d2;
    cout<<"----------------------------------------"<<endl;
    Base2 bb;
}