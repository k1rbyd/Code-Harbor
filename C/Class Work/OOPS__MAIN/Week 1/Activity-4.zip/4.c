#include <stdio.h>
int main()
{
    float a,b,c,d,e,f,g,h,pc,furn,lb;
    printf("Enter the cost of the latest computer and the total count:");
    scanf("%f%f",&a,&b);
    pc=a*b;
    printf("Enter the cost of a table and the total count:");
    scanf("%f%f",&c,&d);
    printf("Enter the cost of a chair and the total count:");
    scanf("%f%f",&e,&f);
    furn=(c*d)+(e*f);
    printf("Enter the number of work hours and wages per hour:");
    scanf("%f%f",&g,&h);
    lb=g*h;
    printf("Cost of computer lab : %.2f \n",pc);
    printf("Cost of furniture : %.2f \n",furn);
    printf("Cost of labor: %.2f \n",lb);
}