#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector <int> list1;
    // for(int i=1;i<10;i++)
    // {
    //     cin>>list1.push_back(i);
    // }
    list1.push_back(1);
    list1.push_back(2);
    list1.push_back(3);
    for(int i=0;i<list1.size();i++)
    {
        cout<<list1[i]<<endl;
    }
}

// we can use insert operation too;
//    here,
//       list1.insert(list1.begin()+3,4);
//    this will add 4 in the 3rd index or we can say 4th position
    