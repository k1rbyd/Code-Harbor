#include <iostream>
using namespace std;

class Test
{
    int a;
    public:
        Test()
        {
            a=10;
            cout<<"default constructor"<<endl;
        }
        void print_data()
        {
            cout<<a<<endl;
        }
        ~Test()
        {
            cout<<"Destructor"<<endl;
        }
};

int main()
{
    Test t1;
    Test *ptr;      // pointer object
    ptr = &t1;
    
    // nameless object 
    // Test();      this is correct, but the object will be destroyed instantly
    
    t1.print_data(); 
    ptr->print_data();
    
    Test *ptr1;
    ptr = new Test();       //dynamic object
    ptr1->print_data();
    delete ptr1;            // WE HAVE TO DO THIS, IF NOT IT WILL ALWAYS EXIST
}	 	  	 	  	  	     		     	      	       	 	

/*

using pointers inside Class

#include <iostream>
using namespace std;

class Test
{
    int *a;
    public:
        Test()
        {
            a=new int(10);
            cout<<"default constructor"<<endl;
        }
        void print_data()
        {
            cout<<a<<endl;
        }
        ~Test()
        {
            cout<<"Destructor"<<endl;
        }
};

int main()
{
    Test t1;
    Test *ptr;      // pointer object
    ptr = &t1;
    
    // nameless object 
    // Test();      this is correct, but the object will be destroyed instantly
    
    t1.print_data(); 
    ptr->print_data();
    
    Test *ptr1;
    ptr = new Test();       //dynamic object
    ptr1->print_data();
    delete ptr1;            // WE HAVE TO DO THIS, IF NOT IT WILL ALWAYS EXIST
}	 	  	 	  	  	     		     	      	       	 	

*/