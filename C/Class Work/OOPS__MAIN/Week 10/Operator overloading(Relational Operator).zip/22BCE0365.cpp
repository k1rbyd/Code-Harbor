#include <iostream>
using namespace std;

class Oper
{
  int a;
  public:
    Oper()
    {
        a=0;
    }
    void get_values()
    {
        cin>>a;
    }
    Oper operator <(Oper x)
    {
        Oper y;
        if(a<x.a)
            y.a=1;
        else if (a>x.a)
            y.a=2;
        else
            y.a=3;
        return y;
    }
    Oper operator >(Oper x)
    {
        Oper y;
        if(a>x.a)
            y.a=1;
        else if(a<x.a)
            y.a=2;
        else
            y.a=3;
        return y;
    }	 	  	 	  	  	     		     	      	       	 	
                                        // Oper operator <=(Oper x)
                                        // {
                                        //     Oper y;
                                        //     if(a>x.a || a==x.a)
                                        //         y.a=1;
                                        //     else
                                        //         y.a=2;
                                        // }
                                        // Oper operator >=(Oper x)
                                        // {
                                        //     Oper y;
                                        //     if(a<x.a || a==x.a)
                                        //         y.a=1;
                                        //     else
                                        //         y.a=2;
                                        // }
    void display()
    {
        if(a==1)
        cout<<"True"<<endl;
        else if(a==2)
        cout<<"False"<<endl;
        else if(a==3)
        cout<<"Equal"<<endl;
    }
};

int main()
{
    Oper a1,a2,a3,a4,a5,a6;
    a1.get_values();
    a2.get_values();
    a3=a1>a2;
    a4=a1<a2;
                                        // a5=a1>=a2;
                                        // a6=a1<=a2;
    a3.display();
    a4.display();
    a5.display();
    a6.display();
}	 	  	 	  	  	     		     	      	       	 	