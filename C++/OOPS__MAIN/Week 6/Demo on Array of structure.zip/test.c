#include <stdio.h>
#include <string.h>

struct Emp{
    int emp_id;
    char emp_name[15];
    float emp_sal;
}e1,e2;

int main()
{
    e1.emp_id=01;
    //e1.emp_name="AAAAA";
    strcpy(e1.emp_name,"AAAAAAAAA");
    e1.emp_sal=1200000.0;
    printf("%d\n%s\n%.2f",e1.emp_id,e1.emp_name,e1.emp_sal);
    e2.emp_id=02;
    strcpy(e2.emp_name,"BBBBBBBBB");
    e2.emp_sal=900000.0;
    printf("%d\n%s\n%.2f\n",e2.emp_id,e2.emp_name,e2.emp_sal);
}