#include <iostream>
using namespace std;

class seconds
{
    int s;
    public:
        seconds()
        {
            s=7200;
        }
        int get()
        {
            return s;
        }
        void show()
        {
            cout<<"seconds:"<<s<<endl;
        }
};

class hours
{
    int h;
    public:
        void operator=(seconds x)
        {
            h=x.get()/3600;
        }
        void show()
        {
            cout<<"hours:"<<h<<endl;
        }
};

int main()
{	 	  	 	  	  	     		     	      	       	 	
    seconds s;
    hours h;
    h=s;
    s.show();
    h.show();
}