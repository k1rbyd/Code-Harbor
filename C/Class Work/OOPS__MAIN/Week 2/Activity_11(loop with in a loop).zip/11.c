#include <stdio.h>
int main()
{
    int n=10;
    int count=0;
    int i,j,k,l;
    for(i=1;i<2;i++)
        {
            count=count+1;
            printf("    %d ",count);
        }
    printf("\n");
    for(j=1;j<3;j++)
        {
            count=count+1;
            printf("  %d  ",count);
        }
    printf("\n");
    for(k=1;k<4;k++)
        {
            count=count+1;
            printf(" %d  ",count);
        }
    printf("\n");
    for(l=1;l<5;l++)
        {
            count=count+1;
            printf("%d   ",count);
        }
    
}	 	  	 	  	  	     		     	      	       	 	
