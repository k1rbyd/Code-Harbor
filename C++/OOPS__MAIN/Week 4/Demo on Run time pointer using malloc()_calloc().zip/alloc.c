
// apart from malloc and calloc, we also got realloc.
// ptr=realloc(ptr,5*sizeof(type));
// this can both extend as well as re allocate the value given

#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n,i;
    printf("Total count:");
    scanf("%d",&n);
    int* ptr_1=(int*)malloc(n*sizeof(int));
    printf("Enter number one by one\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&ptr_1[i]);
    }
    printf("The number details are:");              // malloc
    for (i=0;i<n;i++)
    {
        printf("%d(%p)\n",ptr_1[i],&ptr_1[i]);
    }
    free(ptr_1);
}

/*
    int n,i;
    printf("Total count:");
    scanf("%d",&n);
    char* ptr_1=(char*)calloc(n*sizeof(char));
    printf("Enter number one by one\n");
    for(i=0;i<n;i++)
    {
        scanf("%c",&ptr_2[i]);
    }                                               // calloc
    printf("The number details are:");
    for (i=0;i<n;i++)
    {	 	  	 	  	  	     		     	      	       	 	
        printf("%c(%p)\n",ptr_2[i],&ptr_2[i]);
    }
    free(ptr_2);
*/
