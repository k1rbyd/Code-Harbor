#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<vector<int>> matrix;
    vector<int> rows;
    rows.push_back(1);
    rows.push_back(2);
    rows.push_back(3);
    matrix.push_back(rows);
    rows.clear();
    rows.push_back(4);
    rows.push_back(5);
    rows.push_back(6);
    matrix.push_back(rows);
    for(int i=0;i<matrix.size();i++)
    {
        for(int j=0;j<matrix[i].size();j++)
        {
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
    
}	 	  	 	  	  	     		     	      	       	 	
