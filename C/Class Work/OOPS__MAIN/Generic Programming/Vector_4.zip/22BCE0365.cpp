#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> list1;
    vector<int> list2;
    vector<int> list3;
    
    list1.push_back(1);
    list1.push_back(2);
    list2 = list1;
    
    if(list1==list2)
    {
        cout<<"LISTS 1 AND 2 ARE EQUAL"<<endl;
    }
    else
    {
        cout<<"LIST 1 AND 2 ARE NOT EQUAL"<<endl;
    }
    
    list3 = list1;
    list3.push_back(3);
    
    if(list1==list3)
    {
        cout<<"LISTS 1 AND 3 ARE EQUAL"<<endl;
    }
    else
    {
        cout<<"LIST 1 AND 3 ARE NOT EQUAL"<<endl;
    }
}	 	  	 	  	  	     		     	      	       	 	
