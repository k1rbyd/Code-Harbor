#include <stdio.h>
#include <stdlib.h>    
int main()
{
    int info[1000][7];
    int i, j, sum, avg;
    for (i = 0; i < 3; i++)
    {
        sum = 0;
        printf("Enter the %d reg no, class number, marks in maths eng sci:\n", i+1);
        for (j = 0; j < 5; j++)
        {
            scanf("%d", &info[i][j]);
            if (j >= 2 && j <= 4)
            {
                sum += info[i][j];
            }
        }
        avg = sum / 3;
        info[i][5] = sum;
        info[i][6] = avg;
    }
    
    for (i = 0; i < 3; 1i++)
    {
        printf("%d %d %d %d %d %d %d\n", info[i][0], info[i][1], info[i][2], info[i][3], info[i][4], info[i][5], info[i][6]);
    }
    return 0;
}	 	  	 	  	  	     		     	      	       	 	
