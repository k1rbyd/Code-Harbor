#include <stdio.h>
int main()
{
    int a,b,c,d;
    printf("Enter 3 numbers:");
    scanf("%d%d%d",&a,&b,&c);

    d=c>(a>b?a:b)?c:((a>b)?a:b);

    printf("%d is the greatest number.",d);
}