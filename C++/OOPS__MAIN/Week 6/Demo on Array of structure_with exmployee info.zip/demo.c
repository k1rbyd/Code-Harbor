#include <stdio.h>
#include <string.h>

struct EMP{
    float emp_salary;
};

int main()
{
    printf("For how many employees do you want to find:");
    int n;
    scanf("%d",&n);
    struct EMP e[n];
    int i;
    for(i=0;i<n;i++)
    {
        scanf("%f",&e[i].emp_salary);
    }
    float da,hra,pf;
    float final;
    for(i=0;i<n;i++)
    {
        da = e[i].emp_salary * 0.8;
        hra = e[i].emp_salary * 0.3;
        pf = e[i].emp_salary * 0.12;
        final = e[i].emp_salary + da + hra - pf;
        printf("Final Salary:%.2f\n",final);
    }
}	 	  	 	  	  	     		     	      	       	 	
