#include <iostream>
using namespace std;

class base
{
    int x;
    float y;
    public:
        base()
        {
            x=0;
            y=0;
        }
        base(int a)
        {
            x=a;
            y=2.0;
        }
        void display()
        {
            cout<<"x:"<<x<<endl;
            cout<<"y:"<<y<<endl;
        }
};

int main()
{
    base z;
    z.display();
    base y(8);
    y.display();
}