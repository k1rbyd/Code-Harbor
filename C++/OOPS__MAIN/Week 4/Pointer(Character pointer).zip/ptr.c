#include <stdio.h>
#include <string.h>
#define max 15
int main()
{
    char s[max];
    char *ptr;
    fgets(s,sizeof(s),stdin);
    ptr=&s;
    printf("%s",s);
    printf("%c",*(s+1));
    printf("%c",*(ptr+1));
}