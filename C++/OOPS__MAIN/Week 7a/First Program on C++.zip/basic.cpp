#include <iostream>
using namespace std;

int main()
{
    int a,b;
    cin>>a>>b;
    cout<<"Sum:"<<a+b<<endl<<"Differnece:"<<a-b<<endl<<"Product:"<<a*b<<endl<<"Quotient:"<<a/b;
}