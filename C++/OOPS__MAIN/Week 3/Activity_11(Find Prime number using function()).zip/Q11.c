#include <stdio.h>
void print_primes(int n);
int main()
{
    int n;
    printf("Enter a positive integer: ");
    scanf("%d", &n);
    printf("Prime numbers up to %d:\n", n);
    print_primes(n);
    return 0;
}

void print_primes(int n)
{
    int i, j;
    int is_prime;
    for (i = 2; i <= n; i++)
    {
        is_prime = 1;
        for (j = 2; j <= i / 2; j++)
        {
            if (i % j == 0)
            {
                is_prime = 0;
                break;
            }
        }
        if (is_prime == 1)
        {
            printf("%d\n", i);
        }
    }
}
	 	  	 	  	  	     		     	      	       	 	
