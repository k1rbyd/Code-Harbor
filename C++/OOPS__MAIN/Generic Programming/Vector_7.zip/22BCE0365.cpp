#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> list;
    list.push_back(1);
    list.push_back(2);
    list.insert(list.begin()+2,3);
    
    for(int i=0;i<list.size();i++)
    {
        cout<<list[i]<<endl;
    }
}