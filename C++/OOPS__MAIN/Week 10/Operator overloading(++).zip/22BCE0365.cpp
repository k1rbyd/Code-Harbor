#include <iostream>
using namespace std;

class Test
{
    int a;
    public:
        Test()
        {
            a=10;
        }
        void operator ++()
        {
            cout<<"Pre-increment"<<"result:"<<++a<<endl;
        }
        void operator ++(int)
        {
            cout<<"Post-increment"<<"result:"<<a++<<endl;
        }
        void display()
        {
            cout<<a<<endl;
        }
};

int main()
{
    Test t1;
    ++t1;
    t1++;
    t1.display();
}