#include <iostream>
using namespace std;

int main()
{
    int a,b;
    cin>>a>>b;
    cout<<"The Value of A:"<<a<<endl<<"The Value of B:"<<b<<endl;
    
    //cout<<"byeeeeeeei"<<endl<<"ooopsssieee";                    // endl is used for a new line here
}