#include <iostream>
using namespace std;

class currency
{
    float inr;
    float usd;
    public:
        currency()
        {
            inr=0;
            usd=0;
        }
        currency(int n,float x)
        {
            if(n==1)
            usd = x;
            if(n==2)
            inr = x;
    
        }
        void tousd()
        {
            usd=inr/82.78;
        }
        void toinr()
        {
            inr = usd*82.78;
        }
        void show()
        {
            cout<<"INR:"<<inr<<endl;
            cout<<"USD:"<<usd<<endl;
        }
};

int main()
{	 	  	 	  	  	     		     	      	       	 	
    
    // here we must use 1 for giving usd and getting inr and 2 for giving inr and getting usd
    
    currency a1(1,1);
    a1.toinr();
    a1.show();
    currency a2(2,82.78);
    a2.tousd();
    a2.show();
}