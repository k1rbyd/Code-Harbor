#include <iostream>
using namespace std;

class Test{
    int a,b;
    public:
        Test(){
            a=1;
            b=1;
        }
        void put_data()
        {
            cout<<a<<endl<<b;
        }
        
        // shallow copy constructor
        
        Test(const Test & temp_obj)
        {
            this->a=temp_obj.a;
            this->b=temp_obj.b;
        }
};
int main()
{
    cout<<"T1 object"<<endl;
    Test t1=Test();
    t1.put_data();
    cout<<"T2 objcet"<<endl;
    Test t2 = Test(t1);         // call to shallow constuctor
    // t2=t1;
    t2.put_data();
    return 0;
}	 	  	 	  	  	     		     	      	       	 	
