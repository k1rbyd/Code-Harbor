#include <iostream>
#include <map>
using namespace std;

int main()
{
    map<string,char> grade_list;
    grade_list["Akshay"]='A';
    grade_list["Bala"]='B';
    map<string,char>::iterator i;
    cout<<i->first<<endl;
    cout<<i->second<<endl;
    i++;
    cout<<i->first<<endl;
    cout<<i->second<<endl;
}