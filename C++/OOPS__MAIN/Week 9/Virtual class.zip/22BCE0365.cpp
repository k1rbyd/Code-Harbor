#include<iostream>
using namespace std;

class Base
{
	public:
		int a{0};
		Base()
		{
			cout<<"This is from Base"<<endl;
		}
		void put_data()
		{
			a=1;
			cout<<"a: "<<a<<endl;
		}
};

class Derived1 : virtual public Base
{
	public:
		int b{0};
		Derived1()
		{
			cout<<"This is from 1st Derived"<<endl;
		}
		void put_data1()
		{
			b=1;
			cout<<"b: "<<b<<endl;
		}
};

class Derived2 : virtual public Base
{
	public:
		int c{0};
		Derived2()
		{	 	  	 	  	  	     		     	      	       	 	
			cout<<"This is from 2nd Derived"<<endl;
		}
		void put_data2()
		{
			c=1;
			cout<<"c: "<<c<<endl;
		}
};

class Base2 : virtual public Derived1, virtual public Derived2
{
	public:
		int d{0};
		Base2()
		{
			cout<<"This is from Base2"<<endl;
		}
		void put_data3()
		{
			d=1;
			cout<<"d: "<<d<<endl;
		}
};

int main()
{
    Base b;
    b.put_data();       // this will print Base and a
    cout<<"------------------------------------------"<<endl;
    Derived1 d1;
    d1.put_data1();     // this will print Base, Derived 1 and b
    cout<<"------------------------------------------"<<endl;
    Derived2 d2;
    d2.put_data2();     // this wil print Base, Derived 2 and c
    cout<<"------------------------------------------"<<endl;
    Base2 b2;
    b2.put_data3();     // this will print all of the 4 along with d

    cout<<"------------------------------------------"<<endl;
    cout<<"------------------------------------------"<<endl;

    cout<<"The pros of using a virtual class"<<endl;
    
    b2.a=1;
    b2.a=2;
    b2.b=3;
    b2.c=4;
    b2.d=9;
    b2.a=9;
    b2.b=9;
    b2.c=9;
    
    cout<<b2.a<<endl<<b2.b<<endl<<b2.c<<endl<<b2.d<<endl;
}	 	  	 	  	  	     		     	      	       	 	