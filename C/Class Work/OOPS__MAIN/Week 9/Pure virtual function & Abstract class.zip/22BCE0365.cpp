#include <iostream>
using namespace std;

class Base 
{
    public:
        virtual void display()=0;       // pure virutal function
};

class Derived:public Base
{
    public:
        void display()
        {
         cout<<"I am Derived"<<endl;
        }
};

// a class which contains only pure virutal functions, its called an Abstract Class

// we camt create object for that class, but we can create pointer objects

int main()
{
    Base b1;    // wont work
    Base *b2;   // will work
    Derived d1;     // will work normally as long as the function display is defined in Derived
    d1.display();
}	 	  	 	  	  	     		     	      	       	 	
