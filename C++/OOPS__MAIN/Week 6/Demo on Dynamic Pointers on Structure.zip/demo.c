#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct EMP_INFO{
    int *emp_id;
    char *emp_name;
}EMP;

int main()
{
    E *e=malloc(sizeof(EMP));
    e->emp_id=malloc(sizeof(int));
    e->emp_name=malloc(sizeof(char)*10);
    *e->emp_id=1;
    strcpy(e->emp_name,"aaaaaaaaaaa");
    printf("%d \t %s \n",*e->emp_id,*e->emp_name);
}