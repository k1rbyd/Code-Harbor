#include <iostream>
using namespace std;
class A
{
    public:
        A()
        {
            cout<<"From Base Class"<<endl;
        }
        ~A()
        {
            cout<<"Destructor 1"<<endl;
        }
};

class B:public A
{
    public:
        B()
        {
            cout<<"From Derived Class"<<endl;
        }
        ~B()
        {
            cout<<"Destructor 2"<<endl;
        }
};

int main()
{
    B b1;
    return 0;
}