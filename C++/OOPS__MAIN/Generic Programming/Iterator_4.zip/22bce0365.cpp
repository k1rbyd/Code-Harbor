#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<vector<int>> mat;
    vector<int> r;
    vector<vector<int>>::iterator i;
    vector<int>::iterator j;
    r.push_back(1);
    r.push_back(2);
    r.push_back(3);
    mat.push_back(r);
    r.clear();
    r.push_back(4);
    r.push_back(5);
    r.push_back(6);
    mat.push_back(r);
    for(i=mat.begin();i!=mat.end();i++)
    {
        for(j=(*i).begin();j!=(*i).end();j++)
        {
            cout<<(*j)<<" ";
        }
        cout<<endl;
    }
}	 	  	 	  	  	     		     	      	       	 	
