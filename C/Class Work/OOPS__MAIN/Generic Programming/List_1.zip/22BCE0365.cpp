#include <iostream>
#include <list>
using namespace std;

int main()
{
    list<int> a;
    a.push_back(5);
    a.push_front(1);
    
    // for displaying the info, we have to declare a iterator
    
    list<int>::iterator i;
    
    for(i=a.begin();i!=a.end();i++)
    {
        cout<<*i<<endl;
    }
}