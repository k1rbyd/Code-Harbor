#include <stdio.h>
int sum(int);
int main()
{
    int n;
    int res;
    scanf("%d",&n);
    res=sum(n);
    printf("%d",res);
}

int sum(int a)
{
    if(a!=0)
    return a + sum(a-1);
    else
    return a;
}