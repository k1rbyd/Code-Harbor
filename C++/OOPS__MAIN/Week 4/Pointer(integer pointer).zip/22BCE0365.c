// pointer
// & will give the address
// * with pointer varibale with give the value

#include <stdio.h>
#include <stdlib.h>
int main()
{
    int a[]={1,2,3,4,5};
    int *ptr;
    ptr=&a;
    printf("%d\n",strlen(a));       // sizeof basically gives us the total size, 4 bytes every element.
    printf("%d\n",sizeof(a));
    printf("%d\n",*(ptr+1));        // gives us 2, as it starts off at the beginning
    
    
}