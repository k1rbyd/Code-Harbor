#include <stdio.h>
void Test();                // function declaration
int main()  
{
    Test();                 // function calling
    return 0;
}

void Test(){                // function defining
    printf("hello thereee~~\n");
}