#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool greaterThan4(int i) {
    return i > 4;
}

int main() {
    vector<int> test = {1, 8, 4};
    
    auto itr = find_if(test.begin(), test.end(), greaterThan4);
    
    if (itr == test.end()) {
        cout << "Element not found\n";
    } else {
        cout << "Element found\n";
    }
    
    return 0;
}
