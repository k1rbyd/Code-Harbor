#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> test = {1, 8, 4};
    int k = 8;
    
    auto itr = find(test.begin(), test.end(), k);
    
    if (itr == test.end()) {
        cout << "Element not found\n";
    } else {
        cout << "Element found\n";
    }
    
    return 0;
}
