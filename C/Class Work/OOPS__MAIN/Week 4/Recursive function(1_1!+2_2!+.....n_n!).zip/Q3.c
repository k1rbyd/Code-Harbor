#include <stdio.h>
float fun(float);
float fact(float);
int main()
{
    float i;
    scanf("%f",&i);
    float res;
    res=fun(i);
    printf("%.2f",res);
}

float fact(float x)
{
    if (x>0)
    {
        return x * fact(x-1);
    }
    else
    {
    return 1;
    }
}   

float fun(float y)
{
    float j;
    float result=0;
    for(j=1;j<=y;j++)
    {
        result=result+ (j/fact(j));
    }
    return result;
}