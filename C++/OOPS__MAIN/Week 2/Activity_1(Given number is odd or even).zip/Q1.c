#include <stdio.h>
// finding odd or even
int main()
{
int n;
printf("Enter the number:");
scanf("%d",&n);
if (n%2==0)
printf("Its a even number.");
else
printf("Its an odd number.");

}