#include <stdio.h>

struct student {
   char name[50];
   int age;
   float gpa;
};

void update_student(struct student *s, char *new_name, int new_age, float new_gpa);
void print_student(struct student s);

int main() {
   struct student s1 = {"John Smith", 20, 3.5};

   printf("Before update:\n");
   print_student(s1);

   update_student(&s1, "Jane Doe", 21, 4.0);

   printf("\nAfter update:\n");
   print_student(s1);

   return 0;
}

void update_student(struct student *s, char *new_name, int new_age, float new_gpa) {
   printf("Updating student:\n");

   sprintf(s->name, "%s", new_name);
   s->age = new_age;
   s->gpa = new_gpa;
}

void print_student(struct student s) {
   printf("Name: %s\n", s.name);
   printf("Age: %d\n", s.age);
   printf("GPA: %.2f\n", s.gpa);
}	 	  	 	  	  	     		     	      	       	 	
