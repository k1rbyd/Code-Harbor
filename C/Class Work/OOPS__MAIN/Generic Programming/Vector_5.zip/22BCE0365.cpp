#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> list;
    list.push_back(1);
    list.push_back(2);
    list.push_back(3);
    
    for(int i=0;i<list.size();i++)
    {
        cout<<list[i]<<endl;
    }
    
    cout<<"---------------------------------------"<<endl;
    
    list.pop_back();
    for(int i=0;i<list.size();i++)
    {
        cout<<list[i]<<endl;
    }
}

// we can also remove elements using the erase, here
// list.erase(list.begin()+1);      here, we will erase the 1st index or the 2nd position elementl	 	  	 	  	  	     		     	      	       	 	
