#include <iostream>
using namespace std;

class Op
{
    int x;
    int y;
    public:
        Op()
        {
            x=0;
            y=0;
        }
        void get_values()
        {
            cin>>x;
            cin>>y;
        }
        Op operator +(Op a1)
        {
            Op a;
            a.x=x+a1.x;
            a.y=y+a1.y;
            return a;
        }
        Op operator -(Op a1)
        {
            Op a;
            a.x=x-a1.x;
            a.y=y-a1.y;
            return a;
        }
        Op operator *(Op a1)
        {
            Op a;
            a.x=x*a1.x;
            a.y=y*a1.y;
            return a;
        }	 	  	 	  	  	     		     	      	       	 	
        Op operator /(Op a1)
        {
            Op a;
            a.x=x/a1.x;
            a.y=y/a1.y;
            return a;
        }
        void display()
        {
            cout<<x<<'+'<<y<<'i'<<endl;
        }
};

int main()
{
    Op a,b,c,d,e,f,g;
    a.get_values();
    b.get_values();
    c=a+b;
    d=a-b;
    e=a*b;
    f=a/b;
    c.display();
    d.display();
    e.display();
    f.display();
}	 	  	 	  	  	     		     	      	       	 	
