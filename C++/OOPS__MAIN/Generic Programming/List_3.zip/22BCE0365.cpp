#include <iostream>
#include <list>
using namespace std;

int main()
{
    list<int> t;
    t.push_front(1);
    t.push_front(2);
    t.push_front(3);
    
    list<int>::iterator itr;
    itr=t.begin();
    
    for(itr=t.begin();itr!=t.end();itr++)
    {
        if(*itr==2)
        {
            t.insert(itr,4);
        }
    }
    
    for(itr=t.begin();itr!=t.end;itr++)
    {
        cout<<*itr<<endl;
    }
}