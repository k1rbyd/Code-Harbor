#include <iostream>
using namespace std;

class Op 
{
public:
    Op() 
    {
        cout << "Constructor called" << endl;
    }

    ~Op() 
    {
        cout << "Destructor called" << endl;
    }

    void* operator new(size_t s) {
        void* ptr = malloc(s);
        return ptr;
    }

    void operator delete(void* ptr) 
    {
        free(ptr);
    }
};

int main() {
    Op* item = new Op();
    delete item;
}
