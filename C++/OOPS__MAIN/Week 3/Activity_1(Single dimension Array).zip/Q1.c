#include <stdio.h>
int main()
{
    int num[5];
    int i;
    for(i=0;i<5;i++){
        printf("Enter the value of the %d element: ",i+1);
        scanf("%d",&num[i]);
    }    
    int avg,sum=0;
    for(i=0;i<5;i++){
        sum=sum+num[i];
    }
    avg = sum/5.0;
    printf("The average is %d and the sum is %d.",avg,sum);
    return 0;
}
    