#include <iostream>
using namespace std;

class A {
    private:
        int a {10};
        int b {20};
    public:
        friend class B;
};

class B {
    private:
        int c {30};
    public:
        void showA1(A a1) {
            cout << "a1.a = " << a1.a << endl;
        }
        void showA2(A a1) {
            cout << "a1.b = " << a1.b << endl;
        }
};

int main() {
    A a1;
    B b1;
    b1.showA1(a1);
    b1.showA2(a1); 
    return 0;
}
