#include <iostream>
#include <map>
using namespace std;

int main()
{
    map<string,char> l;
    l["aaa"]='A';
    l["bbb"]='B';
    l["ccc"]='C';
    l.erase("aaa");
    map<string,char>::iterator i;
    for(i=l.begin();i!=l.end();i++)
    {
        cout<<(*i).first<<" "<<(*i).second<<endl;
    }
}