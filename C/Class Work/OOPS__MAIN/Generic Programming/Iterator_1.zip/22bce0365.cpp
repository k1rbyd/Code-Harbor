#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> x(9);
    x[0]=1;
    x[1]=2;
    vector<int>::iterator i;
    for(i=x.begin();i!=x.end();i++)
    {
        cout<<*i<<endl;
    }
}