#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
using namespace std;

int main() {
    vector<int> test = {1, 8, 4, 1};
    
    int sum = accumulate(test.begin(), test.end(), 0);
    
    cout << sum << endl;
    
    return 0;
}
