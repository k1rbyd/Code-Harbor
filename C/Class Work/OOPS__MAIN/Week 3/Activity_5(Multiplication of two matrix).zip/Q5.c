#include <stdio.h>
int main()
{
    int i,j;
    int a,b;
    printf("Enter the number of rows and columns:");
    scanf("%d%d",&a,&b);
    int A[a][b],B[a][b],C[a][b];
    printf("Enter the data inside matrix A:");
    for(i=0;i<a;i++){
        for(j=0;j<b;j++){
            scanf("%d",&A[i][j]);
        }
    }
    printf("Enter the data inside matrix B:");
    for(i=0;i<a;i++){    
        for(j=0;j<b;j++){
            scanf("%d",&B[i][j]);
        }
    }
    printf("The product of those 2 matrices:\n");
    for(i=0;i<a;i++)
    {
        for(j=0;j<b;j++)
        {
            C[i][j]=A[i][j] * B[i][j];
        }
    }

    for(i=0;i<a;i++)
    {
        for(j=0;j<b;j++)
        {
            printf("%d ",C[i][j]);
        }
        printf("\n");
    }	 	  	 	  	  	     		     	      	       	 	
}