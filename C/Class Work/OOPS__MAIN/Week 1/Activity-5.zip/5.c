#include <stdio.h>
int main()
{
    float r;
    printf("Enter the radius:");
    scanf("%f",&r);
    float area,dia,cir;
    area = 3.14 * r * r;
    dia = 2*r;
    cir = 2 * 3.14 * r;
    printf("The area is : %.2f \n",area);
    printf("The diameter is : %.2f \n",dia);
    printf("The circumference is : %.2f \n",cir);
}