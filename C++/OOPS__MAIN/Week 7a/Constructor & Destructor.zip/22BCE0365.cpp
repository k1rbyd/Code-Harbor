/*
#include <iostream>
using namespace std;

class test{
    private:        // this part can be skipped as it is automatically in private mode
        int a,b;    
    public:
        void input()
        {
            cin>>a>>b;                  // default cosntructor here will be, test(){}
        }                             // [constructor with no arugment is default constructor]
        void display()           // constructor doesnt return any value, therby it has no return type
        {
            cout<<a<<endl<<b;           // class name and constructor will be the same
        }
};

int main()
{
    test t1;
    t1.input();
    t1.display();
}
*/
// constrcutor can also take aruguments

#include <iostream>
using namespace std;

class test{
    int a,b;
    public:
        test()
        {
            cout<<"DEFAULT CONSTRUCTOR"<<endl;
            a=100;                                          // constructor
            b=200;
        }	 	  	 	  	  	     		     	      	       	 	
        test(int x, int y)
        {
            cout<<"Constructor with arguements"<<endl;
            a=x;
            b=y;
        }
        void input()
        {
            cin>>a>>b;
        }
        void display()
        {
            cout<<a<<endl<<b<<endl;
        }
        ~test()
        {                                                   // destructor
            cout<<"Object was destroyed"<<endl;             // there will be only one type of destructor
        }
};

int main()
{
    test t1;
    t1.display();
    test t2(10,20);
    t2.display();
}



	 	  	 	  	  	     		     	      	       	 	
