#include <stdio.h>

int fun(int);

int main()
{
    int n[5];
    int sum;
    int i;
    for(i=0;i<5;i++)
    {
        scanf("%d",&n[i]);
    }
    for(i=0;i<5;i++)
    {
     fun(i);   
    }
    sum=fun(i);
    printf("The sum of the items in an array = %d.",sum);
}

int fun(int i){
    int sum;
    sum = sum + i;
    return sum;
}