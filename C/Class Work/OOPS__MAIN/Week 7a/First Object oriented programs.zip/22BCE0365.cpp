#include <iostream>
using namespace std;

class Box{
    private:
        int l,w,h;              //unlike here, structures have only public divisions, i.e. there is no private divisions
    public:
        void input()
        {
            cin>>l>>w>>h;
        }
        void volume()
        {
           cout<<"Volume:"<<l*w*h;
        }
};

int main()
{
    Box b1;                         // object creation
    b1.input();
    b1.volume();
}