#include <iostream>
using namespace std;

class functions{
    private:
        int a,b;
    public:
        void input()
        {
            cin>>a>>b;
        }
        void add()
        {
            cout<<"Sum:"<<a+b<<endl;
        }
        void sub()
        {
            cout<<"Differnce:"<<a-b<<endl;
        }
        void mul()
        {
            cout<<"Product:"<<a*b<<endl;
        }
        void divi()
        {
            cout<<"Quotient:"<<a/b<<endl;
        }
};

int main()
{
    functions f1;
    f1.input();
    f1.add();
    f1.sub();
    f1.mul();
    f1.divi();
}	 	  	 	  	  	     		     	      	       	 	