#include <stdio.h>
#include <string.h>
int main()
{
    char s[10];
    gets(s);
    puts(s);
    return 0;
}