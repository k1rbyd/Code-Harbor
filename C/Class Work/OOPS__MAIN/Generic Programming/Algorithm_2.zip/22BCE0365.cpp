#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool wayToSort(int i, int j) {
    return i > j;
}

int main() {
    vector<int> test = {1, 8, 4};
    
    sort(test.begin(), test.end(), wayToSort);
    
    for (const auto& num : test) {
        cout << num << " ";
    }
    
    return 0;
}
