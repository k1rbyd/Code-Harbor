#include <iostream>
using namespace std;

class Base1
{
    private:
        int a{0};
    protected:
        int a1{1};
    public:
        int a2{2};
        Base1()
        {
        cout<<"This is from the Base1 class"<<endl;
        }
};

class Base2
{
    private:
        int b{0};
    protected:
        int b1{1};
    public:
        int b2{2};
        Base2()
        {
        cout<<"This is from the Base2 class"<<endl;
        }
};

// Derived class is a class that inherits both Base1 and Base2

class Derived :public Base1, public Base2
{
    public:
        int x{0};
        Derived()
        {	 	  	 	  	  	     		     	      	       	 	
        cout<<"This is from the derived class"<<endl;
        }
};

int main()
{
    Derived d1;
}