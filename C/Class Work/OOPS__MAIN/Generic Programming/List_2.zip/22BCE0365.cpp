#include <iostream>
#include <list>
using namespace std;

int main()
{
    list<int> a;
    a.push_front(0);
    a.push_back(1);
    a.push_back(2);
    list<int>::iterator i;
    i = a.begin();
    a.insert(++i,3);
    for(i=a.begin();i!=a.end();i++)
    {
        cout<<*i<<endl;
    }
}