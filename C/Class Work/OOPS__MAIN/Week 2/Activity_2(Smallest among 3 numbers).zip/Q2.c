// read 3 numbers and find the smallest
#include <stdio.h>
int main()
{
    int a,b,c;
    printf("Enter the 3 numbers:");
    scanf("%d%d%d",&a,&b,&c);
    
    if ((a==b) || (b==c) || (a==c))
    printf("Please give non equal numbers");
    else if (a<b){
        if (a<c)
        printf("%d is the smallest number.",a);
    }
    else if (b<a){
        if (b<c)
        printf("%d is the smallest number.",b);
    }
    else
    printf("%d is the smallest number.",c);
}