#include <iostream>
using namespace std;

class Test{
    int a;
    public:
        Test()
        {
            a=10;
        }
        void print_data()
        {
            cout<<a<<endl;
        }

};

void display(Test t1)
{
    t1.print_data();
    
}

int main()
{
    Test obj;
    display(obj);
    return 0;
}