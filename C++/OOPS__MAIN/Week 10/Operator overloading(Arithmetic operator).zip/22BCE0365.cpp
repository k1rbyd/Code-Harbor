#include <iostream>
using namespace std;

class Test
{
    int a;
    public:
        Test()
        {
            a=0;
        }
        void get_values()
        {
            cin>>a;
        }
        void display()
        {
            cout<<a<<endl;
        }
        Test operator +(Test t2)
        {
            Test temp;
            temp.a=a+t2.a;
            return temp;
        }
        Test operator -(Test t2)
        {
            Test temp;
            temp.a=a-t2.a;
            return temp;
        }
        Test operator *(Test t2)
        {
            Test temp;
            temp.a=a*t2.a;
            return temp;
        }	 	  	 	  	  	     		     	      	       	 	
        Test operator /(Test t2)
        {
            Test temp;
            temp.a=a/t2.a;
            return temp;
        }
};

int main()
{
    Test t1,t2,t3,t4,t5,t6;
    t1.get_values();
    t2.get_values();
    t3=t1+t2;
    t4=t1-t2;
    t5=t1*t2;
    t6=t1/t2;
    t3.display();
    t4.display();
    t5.display();
    t6.display();
}