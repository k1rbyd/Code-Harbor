#include <stdio.h>

void print_primes(int start, int end);

int main()
{
    int n1, n2;
    printf("Enter a range of positive integers:\n");
    printf("Start: ");
    scanf("%d", &n1);
    printf("End: ");
    scanf("%d", &n2);
    printf("Prime numbers between %d and %d:\n", n1, n2);
    print_primes(n1, n2);
    return 0;
}
void print_primes(int start, int end)
{
    int i, j;
    int is_prime;
    for (i = start; i <= end; i++)
    {
        is_prime = 1;
        for (j = 2; j <= i / 2; j++)
        {
            if (i % j == 0)
            {
                is_prime = 0;
                break;
            }
        }
        if (is_prime == 1)
        {
            printf("%d\n", i);
        }
    }
}	 	  	 	  	  	     		     	      	       	 	
