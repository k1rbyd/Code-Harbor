#include <stdio.h>

union myUnion {
    int i;
    float f;
    char c;
};

int main() {
    union myUnion u;
    u.i = 65; // Assign the ASCII code for 'A' to the integer member

    printf("u.i = %d\n", u.i); // Output the integer value
    printf("u.f = %f\n", u.f); // Output the float value
    printf("u.c = %c\n", u.c); // Output the character value

    return 0;
}
