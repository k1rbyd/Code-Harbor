#include <stdio.h>

int fact(int);

int main()
{
    int i;
    int res;
    scanf("%d",&i);
    res = fact(i);
    printf("%d",res);
}

int fact(int a)
{
    if (a==0)
    return 1;
    if (a==1)
    return 1;
    else
    return a * fact(a-1);
}