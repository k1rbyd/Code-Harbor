#include <stdio.h>
void address(int*);
int main()
{
    int a;
    printf("Enter the value of a:");
    scanf("%d",&a);
    address(&a); 
    printf("%d",a);
}
void address(int *ptr)
{
    *ptr = 100;
}