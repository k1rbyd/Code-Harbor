#include <stdio.h>
int main()
{
    float pay,salary;
    printf("Enter the Basic Salary:");
    scanf("%f",&pay);
    float da,hra,pf;
    da = pay*0.8;
    hra = pay*0.3;
    pf=pay*0.12;
    salary = pay + da + hra - pf;
    printf("The Salary : %.2f",salary);
}