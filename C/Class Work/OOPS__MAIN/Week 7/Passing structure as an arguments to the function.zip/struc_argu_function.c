#include <stdio.h>
#include <string.h>

struct student {
   char name[50];
   int age;
   float gpa;
};

struct student update_student(struct student s, char new_name[], int new_age, float new_gpa);
void print_student(struct student s);

int main() {
   struct student s1;

   printf("Enter name: ");
   scanf("%[^\n]%*c", s1.name);

   printf("Enter age: ");
   scanf("%d", &s1.age);

   printf("Enter GPA: ");
   scanf("%f", &s1.gpa);

   printf("Before update:\n");
   print_student(s1);

   char new_name[50];
   int new_age;
   float new_gpa;

   printf("Enter new name: ");
   scanf("%[^\n]%*c", new_name);

   printf("Enter new age: ");
   scanf("%d", &new_age);

   printf("Enter new GPA: ");
   scanf("%f", &new_gpa);

   s1 = update_student(s1, new_name, new_age, new_gpa);

   printf("\nAfter update:\n");
   print_student(s1);

}	 	  	 	  	  	     		     	      	       	 	

struct student update_student(struct student s, char new_name[], int new_age, float new_gpa) {
   printf("Updating student:\n");

   sprintf(s.name, "%s", new_name);
   s.age = new_age;
   s.gpa = new_gpa;

   return s;
}

void print_student(struct student s) {
   printf("Name: %s\n", s.name);
   printf("Age: %d\n", s.age);
   printf("GPA: %.2f\n", s.gpa);
}
