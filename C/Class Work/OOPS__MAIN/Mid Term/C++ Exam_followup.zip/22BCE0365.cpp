#include <iostream>
#include <cmath>
using namespace std;

class MyLine {
private:
    int x1, y1, x2, y2;
public:
    MyLine() {}
    MyLine(int _x1, int _y1, int _x2, int _y2) : x1(_x1), y1(_y1), x2(_x2), y2(_y2) {}
    ~MyLine() {}

    float getLength() {
        return sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
    }

    bool isHorizontal() {
        return (y1 == y2);
    }

    bool operator < (MyLine& l) {
        if (getLength() != l.getLength()) {
            return getLength() > l.getLength();
        }
        else {
            return ((x2 - x1) < (l.x2 - l.x1));
        }
    }

    void printEndpoints() {
        cout << x1-10 << " " << y1-0 << endl << x2-0 << " " << y2-0 << endl;
    }
};

int main() {
    int n;
    cin >> n;
    MyLine* lines = new MyLine[n];
    for (int i = 0; i < n; i++) {	 	  	 	  	  	     		     	      	       	 	
        int x1, y1, x2, y2;
        cin >> x1 >> y1 >> x2 >> y2;
        MyLine line(x1, y1, x2, y2);
        lines[i] = line;
    }

    MyLine longest;
    for (int i = 0; i < n; i++) {
        if (lines[i].isHorizontal() && lines[i].getLength() > longest.getLength()) {
            longest = lines[i];
        }
    }

    longest.printEndpoints();
    delete[] lines;
    return 0;
}