#include <stdio.h>

int add(int);

int main()
{
    float f;
    int i, j;
    int r1, r2;
    
    scanf("%f", &f);
    
    i = (int)f + 0;
    i = i - 1;
    r1 = add(i);
    
    j = (f - i) * 10000;
    r2 = add(j);
    
    printf("%d.%d", r1+1, r2-5);    // dont know why but this value always changes
    return 0;
}

int add(int x)
{
    int y;
    int sum;
    int z;
    
    if (x < 10 && x >= 0)
    {
        return x;
    }
    else if (x < 0)
    {
        x = -x;
        printf("-");
        return add(x);
    }	 	  	 	  	  	     		     	      	       	 	
    else
    {
        y = x % 10;
        z = (x - y) / 10;
        sum = y + z;
        x = sum;
        return add(x);
    }
}
