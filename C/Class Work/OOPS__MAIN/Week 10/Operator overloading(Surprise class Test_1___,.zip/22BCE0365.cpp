#include <iostream>
using namespace std;

class Person {
private:
    string name;
    int age;

public:
    Person(const string& n = "", int a = 0) : name(n), age(a) {}

    friend ostream& operator<<(ostream& os, const Person& p) {
        os << "Name: " << p.name << ", Age: " << p.age;
        return os;
    }

    friend istream& operator>>(istream& is, Person& p) {
        cout << "Enter the person's name: ";
        is >> p.name;
        cout << "Enter the person's age: ";
        is >> p.age;
        return is;
    }
};

int main() {
    // Person p1("John Doe", 30);
    // cout << p1 << endl;

    Person p2;
    cin >> p2;
    cout<< p2 << endl;
}
	 	  	 	  	  	     		     	      	       	 	
