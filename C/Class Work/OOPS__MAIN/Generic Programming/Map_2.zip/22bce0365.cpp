#include <iostream>
#include <string>
#include <map>
using namespace std;

int main()
{
    map<string,char> grade_list;
    grade_list["aaaaaaaaaaaaaaaa"]='A';
    grade_list["bbbbbbbbbbbbbbbb"]='B';
    grade_list["cccccccccccccccc"]='C';
    grade_list["aaaaaaaaaaaaaaaa"]='Z';
    
    map<string,char>::iterator i;
    i=grade_list.begin();
    cout<<i->first<<endl;
    cout<<i->second<<endl;
    i++;
    cout<<i->first<<endl;
    cout<<i->second<<endl;
}