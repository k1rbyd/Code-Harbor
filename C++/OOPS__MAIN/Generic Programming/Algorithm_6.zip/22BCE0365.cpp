#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool greaterThan1(int i) {
    return i > 1;
}

int main() {
    vector<int> test = {1, 8, 4, 1};
    
    int ct = count_if(test.begin(), test.end(), greaterThan1);
    
    cout << ct << endl;
    
    return 0;
}
