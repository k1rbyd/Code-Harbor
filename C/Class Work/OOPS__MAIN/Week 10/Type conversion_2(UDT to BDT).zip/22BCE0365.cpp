#include <iostream>
using namespace std;

class base
{
    int x;
    float y;
    public:
        base()
        {
            x=0;
            y=0;
        }
        operator int()
        {
            return (x);
        }
        operator float()
        {
            return (y);
        }
        base(int a)
        {
            x=a;
            y=2.0;
        }
        void show()
        {
            cout<<"x:"<<x<<endl;
            cout<<"y:"<<y<<endl;
        }
};

int main()
{
    int c;
    float d;
    base a(10);
    c=a;
    d=a;
    cout<<c<<endl;
    cout<<d<<endl;
}	 	  	 	  	  	     		     	      	       	 	