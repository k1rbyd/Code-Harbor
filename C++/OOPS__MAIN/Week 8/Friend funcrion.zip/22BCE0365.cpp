#include <iostream>
using namespace std;

class B;

class A
{
    int a;
    public:
        A()
        {
            a=1;
        }
        friend void display(A,B);
};

class B
{
    int b;
    public: 
        B()
        {
            b=2;
        }
        friend void display(A,B);
};

// friend fuction can access private data

void display(A a1,B b1)
{
    cout<<a1.a +b1.b<<endl;
}

int main()
{
    A a1;
    B b1;
    display(a1,b1);
    
}