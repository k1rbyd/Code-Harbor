#include <iostream>
using namespace std;

class Base
{
    public:
        Base()
        {
            cout<<"This is from Base"<<endl;
        }
};

class Base1:public Base
{
    public:
        Base1()
        {
            cout<<"This is from Base1"<<endl;
        }
};

class Base2 : public Base1
{
    public:
        Base2()
        {
            cout<<"This is from Base2"<<endl;
        }
};

int main()
{
    Base b;
    cout<<"---------------------------------------------------"<<endl;
    Base1 b1;
    cout<<"---------------------------------------------------"<<endl;
    Base2 b2;
    
}	 	  	 	  	  	     		     	      	       	 	