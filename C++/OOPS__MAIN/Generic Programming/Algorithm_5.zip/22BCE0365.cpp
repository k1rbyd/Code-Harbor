#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> test = {1, 8, 4, 1};
    
    int ct = count(test.begin(), test.end(), 1);
    
    cout << ct << endl;
    
    return 0;
}
