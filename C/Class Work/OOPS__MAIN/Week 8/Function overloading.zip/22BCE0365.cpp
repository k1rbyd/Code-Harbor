#include <iostream>
using namespace std;

void Test();
void Test(int);
void Test(int,int);
void Test(int,float);

int main()
{
    Test();
    Test(1);
    Test(1,2);
    Test(1,2.0f);
}

void Test()
{
    cout<<"No Arguments"<<endl;
}

void Test(int x)
{
    cout<<"Single Argument"<<endl;
}

void Test(int x,int y)
{
    cout<<"Double Integers"<<endl;
}

void Test(int x, float y)
{
    cout<<"Mixed Inputs"<<endl;
}