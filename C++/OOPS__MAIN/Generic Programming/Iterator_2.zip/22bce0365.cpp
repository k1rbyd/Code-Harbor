#include <iostream>
#include <vector>
using namespace std;

void display(vector<int> x)
{
    for(int i=0;i<x.size();i++)
    {
        cout<<x[i]<<endl;
    }
}

int main()
{
    vector<int> y;
    y.push_back(1);
    y.push_back(2);
    display(y);
}