#include <stdio.h>
int add(int,int);
int mul(int,int);
int dive(int,int);
int sub(int,int);
int main()
{
    int n1, n2;
    printf("Enter the 2 number you want to add:");
    scanf("%d%d",&n1,&n2);
    printf("Addition:%d.\n",add(n1,n2));
    printf("Subtraction:%d.\n",sub(n1,n2));
    printf("Divison:%d.\n",dive(n1,n2));
    printf("Multiplication:%d.\n",mul(n1,n2));
}

int add(int a, int b){
    return (a+b);
}

int sub(int a, int b){
    return (a-b);
}

int dive(int a, int b){
    return (a/b);
}

int mul(int a, int b){
    return (a*b);
}	 	  	 	  	  	     		     	      	       	 	
