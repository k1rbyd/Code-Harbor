#include <iostream>
#include <map>
using namespace std;

int main()
{
    map<string,char> l;
    l["aaa"]='A';
    l["bbb"]='B';
    cout<<l.size();
}