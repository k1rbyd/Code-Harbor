#include <iostream>

using namespace std;

class Exercise 
{
public:
    int operator[](int n) 
    {
        return n * n;
    }

    int operator()(int k, int l) {
        return k - l;
    }
};

int main() {
    Exercise obj;
    int n1,n2,n3;
    cin>>n1;
    int a = obj[n1];
    cout << a << endl;

    cin>>n2>>n3;
    int b = obj(n2, n3);
    cout << b << endl;

}
