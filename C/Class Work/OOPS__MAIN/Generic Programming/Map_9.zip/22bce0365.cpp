#include <iostream>
#include <map>
using namespace std;

int main()
{
    map<string,char> list;
    list["aa"]='A';
    list["bb"]='B';
    list.clear();
    if(list.empty())
    cout<<"EMPTY";
    else
    cout<<"NOT EMPTY";
}