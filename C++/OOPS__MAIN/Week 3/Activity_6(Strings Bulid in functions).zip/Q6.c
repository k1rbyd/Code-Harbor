#include <stdio.h>
#include <string.h>
int main()
{
    char test[100];
    scanf("%s",test);
    char copy[1000];
    printf("The copy of the string: %s\n",strcpy(copy,test));
    printf("The length of the string: %d\n",strlen(test));
    printf("The above string in CAPS: %s\n",strupr(test));
    printf("The above string in lower: %s\n",strlwr(test));
    printf("The reverse of the string: %s\n",strrev(test));
    printf("The first occurence: %s",strchr(test));
    printf("The occurence in the reverse order: %s\n",strrchr(test));
    printf("Combination of the string and its copy: %s\n",strcat(test,copy));
    printf("%d",strnset(test,'*',3));
    printf("%d",strset(test,'*'));
    return 0;
}